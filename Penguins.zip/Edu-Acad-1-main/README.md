# Project Name- Edu-Acad

# Our Aim
Education is the process of learning and sharing. We, as an education platform provides recourses and abundant opportunities to students in almost every field from digital marketing to machine learning. We help that there is no more powerful tool than education. Education is the only weapon that can bring change in society. With this thought, we provide free resources and guide students across the platforms. Through this, we can make learning more easier and in an interesting way. We have made this website completely responsive so that students can easily view it on any screen.

# Project Members-
Priya Kumari- priyakumari02
Aditi Jha- aditi944
Shivani Singh- shivani0701
Ayushi Gupta-

# Hackathon- Hack-O-Uplift 

# Tools that we used- VS code
We used VS code to develop the project

# Deployment tool- Netlify
We deployed our website on netlify so that it can easily be viewed.

# To view our project live, click on the link below
https://quizzical-kowalevski-9f69c6.netlify.app/

# Tech stacks that we used
HTML, CSS, JavaScript

# Participation of each member in this project
We made the video and PPT altogether. The project idea was given by each and every member.
1. Ayushi Gupta- developed strategy, design and fixed various isses that we faced
2. Priya Kumari- developed all the section of project and fixed various issues
3. Shivani Singh- desined the project, gathered graphics and fixed various issues
4. Aditi Jha- designed logo, content, and fixed issues

# Our inspiration behind this project-
We decided to provide students with free and quality recouces from where they can get everything. Our inspiration is that many students don't have proper and useful resouces to kickstant their career. We provide them with oppurtunities and valid resources. 

# Challenges that we run into
We faced many issues after the completetion of the project like responsiveness and designing issues. It took much time to fix all those issues that we faced.

# Accompleshments that we are most proud of
We are most proud of our team work and development strategy.

# Our learning from this project-
* We learnt to work in a team
* We learn many new concepts that we never used before


